package com.amdevelopstudios.near;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;
import java.util.Timer;
import java.util.TimerTask;
import android.net.NetworkRequest;

public class MainActivity extends Activity 
{
    private Timer _timer = new Timer();
    
    private double a = 0;
    
    private Button button1;
    private EditText edittext1;
    private WebView webview1;
    private SeekBar seekbar1;
    
    private AlertDialog.Builder dialog;
    private Intent in = new Intent();
    private TimerTask timer;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        button1 = (Button) findViewById(R.id.button1);
        seekbar1 = (SeekBar) findViewById(R.id.seekbar1);
        edittext1 = (EditText) findViewById(R.id.edittext1);
        webview1 = (WebView) findViewById(R.id.webview1);
        webview1.getSettings().setJavaScriptEnabled(true);
        webview1.getSettings().setSupportZoom(true);
        dialog = new AlertDialog.Builder(this);
        
        seekbar1.setVisibility(View.GONE);
        
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View _view){
                if (edittext1.getText().toString().contains("https://") || edittext1.getText().toString().contains("http://")) {
                webview1.loadUrl(edittext1.getText().toString());
                String load = "Carregando...";
                Toast.makeText(getApplicationContext(), load, Toast.LENGTH_SHORT).show();
                }else{
                    webview1.loadUrl("https://www.google.com/search?source=hp&q=".concat(edittext1.getText().toString()));
                    Toast.makeText(getApplicationContext(), "Carregando...", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
        webview1.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
                final String _url = _param2;
                seekbar1.setVisibility(View.VISIBLE);
                a = 0;
                timer = new TimerTask() {
                    @Override
                    public void run() {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                seekbar1.setProgress((int)a);
                                if (a == 101) {
                                    a = 1;
                                }else{
                                    a++;
                                }
                            }
                        });
                    }
                };
                _timer.scheduleAtFixedRate(timer, (int)(200), (int)(200));
                edittext1.setText(_url);
                super.onPageStarted(_param1, _param2, _param3);
            }
            
            @Override
            public void onPageFinished(WebView _param1, String _param2) {
                final String _url = _param2;
                timer.cancel();
                seekbar1.setVisibility(View.GONE);
                super.onPageFinished(_param1, _param2);
            }
            
        });
        
    }
    
    @Override  
    public boolean onCreateOptionsMenu(Menu menu) {  
        // Inflate the menu; this adds items to the action bar if it is present.  
        getMenuInflater().inflate(R.menu.menu, menu);  
        return true;  
        
    }  

    @Override  
    public boolean onOptionsItemSelected(MenuItem item) {  
        int id = item.getItemId();  
        switch (id){  
            case R.id.item1:  
                dialog.setTitle("Sobre");
                dialog.setMessage("Desenvolvido por: AM Develop Studios\nProgramação: Eduardo Cavalcante\nCanal: Android Master");
                dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface _dialog, int which) {
                        
                    }
                });
                dialog.create().show();

                return true;  
            case R.id.item2:  
                in.setAction(Intent.ACTION_VIEW);
                in.setData(Uri.parse("http://amdevelopstudios.hexat.com"));
                startActivity(in);

                return true;
            case R.id.item3:  
                in.setAction(Intent.ACTION_VIEW);
                in.setData(Uri.parse("https://amdevelopstudios.wordpress.com"));
                startActivity(in);

                return true;  
            case R.id.item4:
                webview1.getSettings().setLoadWithOverviewMode(true);
                webview1.getSettings().setUseWideViewPort(true);
                final String newUserAgent;
                newUserAgent = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36";
                webview1.getSettings().setUserAgentString(newUserAgent);
                webview1.loadUrl(webview1.getUrl());
                
                return true;
            case R.id.item5:
                webview1.getSettings().setLoadWithOverviewMode(true);
                webview1.getSettings().setUseWideViewPort(true);
                final String newUserAgent2;
                newUserAgent2 = "Mozilla/5.0 (Android) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36";
                webview1.getSettings().setUserAgentString(newUserAgent2);
                webview1.loadUrl(webview1.getUrl());
                
                return true;
            default:  
                return super.onOptionsItemSelected(item);  
        }  
    }

    @Override
    public void onBackPressed() {
        if (webview1.canGoBack()) {
            webview1.goBack();
        }else{
            finish();
        }
    }
    
}
